-- Adminer 4.7.9 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP DATABASE IF EXISTS `youtube`;
CREATE DATABASE `youtube` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `youtube`;

DROP TABLE IF EXISTS `canal`;
CREATE TABLE `canal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL COMMENT 'no UNIQUE porque podrían haber varios con el mismo nombre pero diferenciados por URL',
  `url` varchar(250) NOT NULL COMMENT 'no lo pide el ejercicio',
  `descripcion` varchar(250) NOT NULL,
  `usuario_id` int(11) unsigned NOT NULL,
  `fecha` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `canal_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `etiqueta`;
CREATE TABLE `etiqueta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `nombre` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `playlist`;
CREATE TABLE `playlist` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(250) NOT NULL COMMENT 'no UNIQUE porque podrían haber varias con el mismo nombre pero diferenciados por URL',
  `url` varchar(250) NOT NULL COMMENT 'no lo pide el ejercicio',
  `fecha` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `publico` tinyint(4) NOT NULL COMMENT '0 = privado, 1 = público',
  `usuario_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `playlist_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `playlist_item`;
CREATE TABLE `playlist_item` (
  `playlist_id` int(10) unsigned NOT NULL,
  `video_id` int(10) unsigned NOT NULL,
  `orden` smallint(5) unsigned DEFAULT NULL COMMENT 'orden de los videos en el playlist, no lo pide el ejercicio',
  PRIMARY KEY (`playlist_id`,`video_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `playlist_item_ibfk_1` FOREIGN KEY (`playlist_id`) REFERENCES `playlist` (`id`),
  CONSTRAINT `playlist_item_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `video` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `nacimiento` date NOT NULL,
  `sexo` varchar(1) NOT NULL,
  `pais` varchar(25) NOT NULL,
  `cp` smallint(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `usuario_suscripciones`;
CREATE TABLE `usuario_suscripciones` (
  `usuario_id` int(11) unsigned NOT NULL,
  `canal_id` int(11) NOT NULL,
  PRIMARY KEY (`usuario_id`,`canal_id`),
  KEY `canal_id` (`canal_id`),
  CONSTRAINT `usuario_suscripciones_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`),
  CONSTRAINT `usuario_suscripciones_ibfk_2` FOREIGN KEY (`canal_id`) REFERENCES `canal` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `video`;
CREATE TABLE `video` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `titulo` varchar(250) NOT NULL,
  `descripcion` varchar(1000) NOT NULL,
  `tamano` bigint(20) unsigned NOT NULL COMMENT 'max 18446744073709551615',
  `nombre_fichero` varchar(250) NOT NULL,
  `duracion` time NOT NULL,
  `thumbnail_url` varchar(250) NOT NULL COMMENT 'no es buena idea almacenarlo en la base por tema de rendimiento',
  `reproducciones` int(10) unsigned NOT NULL COMMENT 'max 4294967295',
  `likes` int(10) unsigned NOT NULL COMMENT 'max 4294967295',
  `dislikes` int(10) unsigned NOT NULL COMMENT 'max 4294967295',
  `estado` tinyint(4) NOT NULL COMMENT '0 = públic / 1 = ocult / 2 = privat - Veo innecesario otra tabla',
  `usuario_id` int(11) unsigned NOT NULL,
  `publicacion` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `estado_id` (`estado`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `video_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `video_comentario`;
CREATE TABLE `video_comentario` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `video_id` int(10) unsigned NOT NULL,
  `usuario_id` int(11) unsigned NOT NULL,
  `fecha` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  `texto` varchar(250) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `usuario_id` (`usuario_id`),
  KEY `video_id` (`video_id`),
  CONSTRAINT `video_comentario_ibfk_2` FOREIGN KEY (`video_id`) REFERENCES `video` (`id`),
  CONSTRAINT `video_comentario_ibfk_3` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `video_comentario_dislike`;
CREATE TABLE `video_comentario_dislike` (
  `video_comentario_id` int(11) unsigned NOT NULL,
  `usuario_id` int(11) unsigned NOT NULL,
  `fecha` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`video_comentario_id`,`usuario_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `video_comentario_dislike_ibfk_2` FOREIGN KEY (`video_comentario_id`) REFERENCES `video_comentario` (`id`),
  CONSTRAINT `video_comentario_dislike_ibfk_3` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `video_comentario_like`;
CREATE TABLE `video_comentario_like` (
  `video_comentario_id` int(11) unsigned NOT NULL,
  `usuario_id` int(11) unsigned NOT NULL,
  `fecha` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`video_comentario_id`,`usuario_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `video_comentario_like_ibfk_1` FOREIGN KEY (`video_comentario_id`) REFERENCES `video_comentario` (`id`),
  CONSTRAINT `video_comentario_like_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `video_dislikes`;
CREATE TABLE `video_dislikes` (
  `video_id` int(10) unsigned NOT NULL,
  `usuario_id` int(11) unsigned NOT NULL,
  `fecha` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`video_id`,`usuario_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `video_dislikes_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `video` (`id`),
  CONSTRAINT `video_dislikes_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `video_etiqueta`;
CREATE TABLE `video_etiqueta` (
  `video_id` int(10) unsigned NOT NULL,
  `etiqueta_id` int(11) NOT NULL,
  PRIMARY KEY (`video_id`,`etiqueta_id`),
  KEY `etiqueta_id` (`etiqueta_id`),
  CONSTRAINT `video_etiqueta_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `video` (`id`),
  CONSTRAINT `video_etiqueta_ibfk_2` FOREIGN KEY (`etiqueta_id`) REFERENCES `etiqueta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `video_likes`;
CREATE TABLE `video_likes` (
  `video_id` int(10) unsigned NOT NULL,
  `usuario_id` int(11) unsigned NOT NULL,
  `fecha` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE current_timestamp(),
  PRIMARY KEY (`video_id`,`usuario_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `video_likes_ibfk_1` FOREIGN KEY (`video_id`) REFERENCES `video` (`id`),
  CONSTRAINT `video_likes_ibfk_2` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


-- 2021-10-14 04:05:06
